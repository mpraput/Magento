// Put your application javascript here
document.addEventListener('DOMContentLoaded', function () {
    if ($('.single-item').length) {
        $('.single-item').slick({
            lazyLoad: 'ondemand',
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
        });
    }

    onlyColorSwatch();
    buyNowForm();
    dataToolTip();

    function onlyColorSwatch(){
        $('label.only-colorswatch').on('click', function() {
            var productID = $(this).attr('data-productid');
            var newImage = $(this).attr('data-img');
            console.log('#' + productID);
            $('#' + productID).attr('src', newImage);
            $('#' + productID).attr('srcset', newImage);
        });
    }

    function buyNowForm(){
        document.querySelectorAll('.buy-now-form').forEach(function(form) {
            form.addEventListener('submit', function(event) {
            event.preventDefault();
            fetch('/cart/add', {
                method: 'POST',
                body: new FormData(this)
            }).then(function() {
                window.location.href = '/checkout';
            });
            });
        });
    }
    
    //tool tip
    function dataToolTip(){
        var windowWidth = $(window).width();
        if(windowWidth > 1025) {
            $('.item-colorswatch').find('[data-toggle="tooltip"]').tooltip(); 
        } else{
            $('.item-colorswatch').find('[data-toggle="tooltip"]').click(function(){
                $(this).tooltip('show');
            }); 
        }
    }        
    // Remove Bootstrap dropdown toggle functionality to enable hover
    var dropdowns = document.querySelectorAll('.navbar-nav .dropdown, .dropdown-submenu');
    dropdowns.forEach(function (dropdown) {
        dropdown.addEventListener('mouseover', function () {
            this.querySelector('.dropdown-menu').classList.add('show');
        });
        dropdown.addEventListener('mouseout', function () {
            this.querySelector('.dropdown-menu').classList.remove('show');
        });
    });

    var searchIcon      = document.querySelector('.search_icon');
    var searchContainer = document.querySelector('.search_container');
    if (searchIcon && searchContainer) {
        searchIcon.addEventListener('click', function() {
            if (searchContainer.style.display === 'none' || searchContainer.style.display === '') {
                searchContainer.style.display = 'block';
                searchIcon.setAttribute('aria-expanded', 'true');
            } else {
                searchContainer.style.display = 'none';
                searchIcon.setAttribute('aria-expanded', 'false');
            }
        });
    }    
    // Optional: Hide search container when clicking outside
    document.addEventListener('click', function(event) {
        if (searchIcon && searchContainer) {
            if (!searchContainer.contains(event.target) && !searchIcon.contains(event.target)) {
            searchContainer.style.display = 'none';
            searchIcon.setAttribute('aria-expanded', 'false');
            }
        }
    });

    //Start mini cart functionality
    const cartIcon    = document.querySelector('#mini-cart-icon'); // Your cart icon
    const miniCart    = document.getElementById('mini-cart-popup');
    const closeButton = document.getElementById('close-mini-cart');
    const cartItemsContainer = document.getElementById('cart-items'); // New container for items

    // Toggle mini cart visibility
    cartIcon.addEventListener('click', function(e) {
        e.preventDefault()
        miniCart.style.display = miniCart.style.display === 'block' ? 'none' : 'block';
        document.querySelector('.mini-cart-content').classList.add('miniloader');
        updateMiniCart(); // Fetch cart data
    });
    // Close mini cart
    closeButton.addEventListener('click', function() {
        miniCart.style.display = 'none';
    });
    // Function to update mini cart content
    async function updateMiniCart() {
        try {
            const response = await fetch('/cart.json');
            const data     = await response.json();
            cartItemsContainer.innerHTML = ''; // Clear existing items
            if (data.item_count > 0) {
                var cart_sub_total  = Shopify.formatMoney(data.items_subtotal_price);
                var cart_total      = Shopify.formatMoney(data.total_price);
                document.getElementById('minisubtotal').innerHTML =cart_sub_total;
                document.getElementById('minicarttotal').innerHTML =cart_total;
                let itemHTML        = '';
                data.items.forEach(item => {
                    const itemPrice = Shopify.formatMoney(item.price);
                    itemHTML += `
                        <div class="img-content"><div class="img"><img src="${item.image || 'https://via.placeholder.com/50'}" alt="${item.product_title}" style="width: 50px; height: auto;"></div>
                        <div class="content">
                            <p>${item.product_title}</p>
                            <p>Quantity: ${item.quantity}</p>
                            <p>Price: ${itemPrice}</p>
                            <button class="remove-item" data-id="${item.id}">Remove</button>
                        </div></div> `;            
                });
                cartItemsContainer.innerHTML += itemHTML; // Add item to cart
                document.querySelectorAll('.remove-item').forEach(button => {
                    button.addEventListener('click', function() {
                        document.querySelector('.mini-cart-content').classList.add('miniloader');
                        removeItemFromCart(this.dataset.id);
                    });
                });   
            } else {
                cartItemsContainer.innerHTML = '<p>Cart is empty! </p><a href="/collections/all/" class="btn btn-info">Continue Shopping</a>';
                document.getElementById('minisubtotal').innerHTML = '';
                document.getElementById('minicarttotal').innerHTML = '';
                document.querySelector('.subtotal').style.display = 'none';
                document.querySelector('.cart-total').style.display = 'none';
            }
            if(response.ok) {
                document.querySelector('.mini-cart-content').classList.remove('miniloader');
            }
        } catch (error) {
            console.error('Error fetching cart data:', error);
        }
    }

    // Function to remove item from cart
    async function removeItemFromCart(id) {
        try {
            const response = await fetch(`/cart/update.js`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    updates: {
                        [id]: 0 // Set quantity to 0 to remove
                    }
                })
            });
            if (response.ok) {
                updateMiniCart(); // Refresh mini cart after removing item
            } else {
                console.error('Failed to remove item from cart');
            }
        } catch (error) {
            console.error('Error removing item:', error);
        }
    }
    //End mini cart functionality

    // start wishlist
    initWishlistScript();
    function initWishlistScript(){
        var wishlistBtns = document.querySelectorAll('.wishlist-btn');
        if(Shopify.customer) {
                // Save to metafield logic (requires an app or custom API)
        } else {
                // For guest users, use localStorage
        }
        var wishlist     = JSON.parse(localStorage.getItem('wishlist')) || [];
        wishlistBtns.forEach(function(btn) {
        var productId = btn.getAttribute('data-product-url');
        updateWishlistButton(wishlist, btn, productId);
        // Add event listener for wishlist button click
        btn.addEventListener('click', function() {
            if (wishlist.includes(productId)) {
            wishlist = wishlist.filter(id => id !== productId);
            } else {
            wishlist.push(productId);
            }
            localStorage.setItem('wishlist', JSON.stringify(wishlist));
            updateWishlistButton(wishlist, btn, productId);
        });
        });
    }
    function updateWishlistButton(wishlist, button, productId) {
        if (wishlist.includes(productId)) {
          button.innerHTML = '<label for="heart-checkbox" class="heart added">&#10084;</label>';  // Corrected to innerHTML
          button.classList.add('added');
        } else {
          button.innerHTML = '<label for="heart-checkbox" class="heart remove">&#10084;</label>';  // Corrected to innerHTML
          button.classList.remove('added');
        }
    }
    // end wishlist
 
    function handleMouseOver(e) {
        const listmainImg = e.target.getAttribute('src');
        const hoverImages = e.target.getAttribute('data-hover');
        e.target.setAttribute('src', hoverImages);
        e.target.setAttribute('data-original-src', listmainImg);
    }
    
    function handleMouseOut(e) {
        const originalSrc = e.target.getAttribute('data-original-src');
        e.target.setAttribute('src', originalSrc);
    }
    
    // Initialize hover functionality
    imageHover = function() {
        const maiCollectionImages = document.querySelectorAll('.main-cl-image img');
        maiCollectionImages.forEach(maiCollectionImage => {
            maiCollectionImage.addEventListener("mouseover", handleMouseOver);
            maiCollectionImage.addEventListener("mouseout", handleMouseOut);
        });
    }
    
    // Function to remove hover event listeners
    destroyImageHover = function() {
        const maiCollectionImages = document.querySelectorAll('.main-cl-image img');
        maiCollectionImages.forEach(maiCollectionImage => {
            maiCollectionImage.removeEventListener("mouseover", handleMouseOver);
            maiCollectionImage.removeEventListener("mouseout", handleMouseOut);
        });
    }

    infiniteScroll = function(){
        var action = 'scroll load delayed-resize';
        $(window).on(action, function(){
            var moreURL = $('.infinitpagin a').attr('href');
            if($('.infinitpagin a.infinite').length){
                var bottom = $('.infinitpagin').offset();
                var docTop = ($(document).scrollTop() + $(window).height() - 50);
                if( docTop > bottom.top){
                    $(window).off(action);
                    loadMore(moreURL);
                }
            }
        });
    }

    loadMore = function(moreURL) {
        if (moreURL.length){
          var load_more_btn     = $('.load-more_btn ');
          var load_more_spinner = $('.load-more_spinner');
            $.ajax({
              type: 'GET',
              dataType: 'html',
              url: moreURL,
              beforeSend: function(){
                load_more_btn.hide();
                load_more_spinner.show();
              },
              complete: function (data) {
                if($('.products-on-page').length){
                  $('.products-on-page').append($(".products-on-page", data.responseText).html());
                }
                if($(".infinitpagin", data.responseText).html()){
                  $('.infinitpagin').html($(".infinitpagin", data.responseText).html());
                }else {
                  $('.infinitpagin').remove();
                }

                if($('.infinitpagin a.load-more_btn').length){
                    loadMoreBtn();
                } else {
                  infiniteScroll();
                }

                if (typeof quickviewInit === 'function') {
                  console.log('quickview initialize');
                  quickviewInit(); // Re-initialize the quick view for newly loaded products
                }
                if(typeof initWishlistScript === 'function'){
                  initWishlistScript();
                }
                if (typeof onlyColorSwatch === 'function') {
                    onlyColorSwatch(); // This will invoke the function if it is defined
                }
                if(typeof buyNowForm === 'function'){
                  buyNowForm();
                }
                if(typeof dataToolTip === 'function'){
                  dataToolTip();
                }
                destroyImageHover();
                imageHover(); // its image hover fucntion call
              }
            });
        }
      }
  
      loadMoreBtn = function() {
            $('a.load-more_btn').click(function(e){
          e.preventDefault();
          var moreURL = $(this).attr('href');
                loadMore(moreURL);
        });
      }
      
      $(document).ready(function(){
        loadMoreBtn();
        infiniteScroll();
        imageHover()
      });
});

