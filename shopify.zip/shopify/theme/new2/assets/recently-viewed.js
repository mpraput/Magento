document.addEventListener('DOMContentLoaded', () => {
    const displayRecentlyViewed = () => {
        const recentlyViewed    = JSON.parse(localStorage.getItem('recentlyViewed')) || [];
        const productList       = document.getElementById('recently-viewed-list');
        productList.innerHTML   = ''; // Clear the list
        const productPromises = recentlyViewed.map(id => {
            return fetch(`/products/${id}.js`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Failed to fetch product ${id}`);
                    }
                    return response.json();
                })
                .then(product => {
                    return {
                        title: product.title,
                        handle: product.handle,
                        price: product.price,
                        image: product.images[0]
                    };
                })
                .catch(err => {
                    console.error(`Error fetching product ${id}:`, err);
                    return null;
                });
        });

        Promise.all(productPromises).then(products => {
            const validProducts = products.filter(product => product !== null);

            validProducts.forEach(product => {
                const listItem = document.createElement('li');
                var itmePrice = Shopify.formatMoney(product.price);
                listItem.innerHTML = `
                    <a href="/products/${product.handle}">
                        <img src="${product.image}" alt="${product.title}" style="max-width: 100px; height: auto;" />
                    </a>
                    <p>${product.title}</p>
                    <p>Price: ${itmePrice}</p>
                `;
                productList.appendChild(listItem);
            });
            // slider function
            recentProductSlider();
        });
    };

    const updateRecentlyViewed = (productId) => {
        let recentlyViewed  = JSON.parse(localStorage.getItem('recentlyViewed')) || [];
        const index         = recentlyViewed.indexOf(productId);
        if (index !== -1) {
            recentlyViewed.splice(index, 1);
        }
        recentlyViewed.unshift(productId);
        if (recentlyViewed.length > 10) {
            recentlyViewed.pop();
        }
        localStorage.setItem('recentlyViewed', JSON.stringify(recentlyViewed));
    };

    const productId = window.location.pathname.split('/').pop();
    if (productId) {
        updateRecentlyViewed(productId);
    }

    displayRecentlyViewed();
   
    function recentProductSlider(){
        $('#recently-viewed-list').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            autoplay: false,
            autoplaySpeed: 1000,
            arrows: true,
            responsive :[
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 320,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
    }
});