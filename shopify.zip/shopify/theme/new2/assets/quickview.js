
  document.addEventListener('DOMContentLoaded', function() {
    quickviewInit();
  });
  function quickviewInit(){ 
    var bodyEle    = document.getElementById('body');
    var loaderEle  = document.querySelector('.loader-image');
    var modal      = document.getElementById('quick-view-modal');
    var closeModal = document.querySelector('.close-modal');
    document.querySelectorAll('.quick-view-button').forEach(function(button) {
      button.addEventListener('click', function() {
        addLoadingClass(bodyEle, loaderEle);
        var productUrl = this.getAttribute('data-product-url');
        if (productUrl) {
          // Fetch product data with the custom view template
          fetch(productUrl + '.js?view=quick-view')
            .then(response => {
              if (!response.ok) {
                removeLoadingClass(bodyEle, loaderEle);
                throw new Error('Network response was not ok');
              }
              removeLoadingClass(bodyEle, loaderEle);
              return response.json(); // Expecting JSON response
            })
            .then(data => {
                var variants = data.variants;
                let variantHrml = '';
                if(variants.length > 0 ){
                  variantHrml += `<select class="varient_drop_down">`;
                  $(variants).each(function (i, varient) {
                    variantHrml += '<option value="' + varient.id + '" data-varientimg="' + 
                            (varient.featured_image ? varient.featured_image.src : '') + '">' + 
                            varient.title + '</option>';
                  });
                  variantHrml += `</select>`;
                }
                console.log("translations : ", translations);
                console.log("options : ", data.options);
                var options  = data.options;
                let optionHtml = '';
                $(options).each(function (i, option) {
                    var opt = option.name;
                    var optionName = opt.toLowerCase();
                    //if(optionName !=='title'){
                      optionHtml += `<div class="${optionName}-switcher"><label for="${optionName}-select">${opt}:</label>`;
                      console.log('optionName=:', optionName ," optionName: ", translations.color);
                      if(optionName == translations.color){
                        optionHtml += `<select id="color-select">`;
                          $(option.values).each(function (i, value) {
                            optionHtml += '<option value="' + value + '">' + value + '</option>';
                          });
                        optionHtml += `</select>`;
  
                        optionHtml += `<div id="color-boxes" class="color-boxes">`;
                        $(option.values).each(function (i, value) {
                          optionHtml += `<div class="color-box" style="background-color: ${value};" data-color="${value}">${value}</div>`;
                        });
                        optionHtml += `</div>`;
                      }else{
                        optionHtml += `<select id="${optionName}-select">`;
                          $(option.values).each(function (i, value) {
                            optionHtml += '<option value="' + value + '">' + value + '</option>';
                          });
                        optionHtml += `</select>`;
                      }
                      optionHtml += `</div>`;
                    //}  
                });
                var productData = {
                  title: data.title || 'No title available',
                  price: data.price || 'Price not available',
                  url: productUrl,
                  image: data.featured_image || 'https://via.placeholder.com/150',
                  images: data.images || [data.featured_image],
                  optionHtml : optionHtml,
                  variantHrml : variantHrml,
                  variants: data.variants
                };
                removeLoadingClass(bodyEle, loaderEle);
                openModal(productData);
            })
            .catch(error => {
              removeLoadingClass(bodyEle, loaderEle);
              console.error('Error fetching product data:', error);
            });
        } else {
          removeLoadingClass(bodyEle, loaderEle);
          console.error('Product URL is not set.');
        }
      });
    });

    // Close modal when clicking on the close button
    closeModal.addEventListener('click', function() {
      modal.style.display = 'none';
    });
    // Close modal when clicking outside of the modal content
    window.addEventListener('click', function(event) {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  }

  function openModal(productData) {
    var modal      = document.getElementById('quick-view-modal');
    var sizeSelectHtml = productData.optionHtml;
    var variantHrmlHtml = productData.variantHrml;
    var thumbnailImages = productData.images.map(img => `
      <li><img src="${img}" alt="${productData.title}" class="thumbnail-image" style="cursor: pointer; width: 100px; height: auto;"></li>
    `).join('');

    var formattedPrice = Shopify.formatMoney(productData.price);
    var content = `
      <div class="quick-view-product">
        <div class="quick-view-img"><img id="main-image" src="${productData.image}" alt="${productData.title}"><div class="thumbnail-container">
          <ul class="product-photo-thumbs">${thumbnailImages}</ul>
        </div></div><div class="quick-view-data">
        <h2>${productData.title}</h2>
        <div class="product-price">${formattedPrice}</div>        
        <div class="quick-view-select">${sizeSelectHtml}</div>${variantHrmlHtml}
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" value="1" min="1">
        <button id="add-to-cart" >Add to Cart</button>
        <button id="cancel-button">Cancel</button>
        <a href="${productData.url}" class="view-full-product">View Full Product</a>
        </div>
      </div>
    `;

    document.getElementById('quick-view-product-content').innerHTML = content;
    modal.style.display = 'block';

    ScriptForChangeMainImg();

    const colorSelect = document.getElementById('color-select');
    if(colorSelect){
      const colorBoxes = document.querySelectorAll('.color-box');
      document.querySelector(`[data-color="${colorSelect.value}"]`).classList.add('selected');
      colorBoxes.forEach(box => {
          box.addEventListener('click', function() {
              colorBoxes.forEach(box => box.classList.remove('selected'));
              this.classList.add('selected');
              // Update the hidden select element to match the clicked color
              colorSelect.value = this.getAttribute('data-color');
          });
      });
    } 
    // Add event listener for thumbnail image clicks
    document.querySelectorAll('.thumbnail-image').forEach(function(thumbnail) {
      thumbnail.addEventListener('click', function() {
        var newSrc = this.getAttribute('src');
        document.getElementById('main-image').setAttribute('src', newSrc);
      });
    });

    // Add event listener for "Add to Cart" button
    document.getElementById('add-to-cart').addEventListener('click', function() {
      var quantity     = parseInt(document.getElementById('quantity').value, 10);
      var variantId    = 1;
      var selectedOptions = Array.from(document.querySelectorAll('.quick-view-select select'))
            .map(select => select.value)
            .join(' / ');
      console.log('selectedOptions : ', selectedOptions);
      const variantDropdown = document.querySelector('.varient_drop_down');
      const matchingVariant = Array.from(variantDropdown.options).find(option => option.innerText === selectedOptions);
      if (matchingVariant) {
        variantId = matchingVariant.value;
        console.log("variantId :", variantId);
      }

      if (quantity && !isNaN(quantity)) {
        addToCart(variantId, quantity);
      } else {
        alert('Please enter a valid quantity.');
      }
    });
    // Add event listener for "Cancel" button
    document.getElementById('cancel-button').addEventListener('click', function() {
      modal.style.display = 'none';
    });

    thumbnailSlider();
  }

  // Function to add product to the cart
  function addToCart(variantId, quantity) {
    var bodyEle    = document.getElementById('body');
    var loaderEle  = document.querySelector('.loader-image');
    var modal      = document.getElementById('quick-view-modal');
    addLoadingClass(bodyEle, loaderEle);
    var data = {
      id: variantId,
      quantity: quantity
    };
    fetch('/cart/add.js', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
      updateCartCount(); // update cart itme count
      removeLoadingClass(bodyEle, loaderEle);
      modal.style.display = 'none'; // Close modal after adding to cart
      window.scrollTo(0,0); // scroll to top
    })
    .catch(error => {
      removeLoadingClass(bodyEle, loaderEle);
      console.error('Error adding product to cart:', error);
      alert('There was an error adding the product to the cart.');
    });
  }
  
  function addLoadingClass(bodyEle, loaderEle){
    bodyEle.classList.add("loading");
    loaderEle.classList.add("loading");
  }
  function removeLoadingClass(bodyEle, loaderEle){
    bodyEle.classList.remove("loading");
    loaderEle.classList.remove("loading");
  }

  function updateCartCount() {
    fetch('/cart.js')
      .then(response => response.json())
      .then(cart => {
        var cartCount = cart.item_count; // Get the total number of items in the cart
        document.getElementById('CartCount').innerHTML = '<span>'+cartCount+'</span>';
      })
      .catch(error => console.error('Error fetching cart data:', error));
  }

  // change color image when click on color switch

  function ScriptForChangeMainImg(){
    const colorSelect         = document.getElementById('color-select');
    const colorBoxesContainer = document.getElementById('color-boxes');
    if (colorSelect && colorBoxesContainer) {
      const colorBoxes      = document.querySelectorAll('.color-box');
      const variantDropdown = document.querySelector('.varient_drop_down');
      const productImage    = document.getElementById('main-image');
  
      // Event delegation for color boxes
      colorBoxesContainer.addEventListener('click', function(event) {
        if (event.target.classList.contains('color-box')) {
          colorBoxes.forEach(box => box.classList.remove('selected'));
          const selectedBox = event.target;
          selectedBox.classList.add('selected');
          colorSelect.value = selectedBox.getAttribute('data-color');
          // Get selected options from all select inputs
          let selectedOptions = Array.from(document.querySelectorAll('.quick-view-select select'))
            .map(select => select.value)
            .join(' / ');
            console.log('selectedOptions : ', selectedOptions);
          // Find and set the corresponding variant
          const matchingVariant = Array.from(variantDropdown.options).find(option => option.innerText === selectedOptions);
          if (matchingVariant) {
            if(matchingVariant.getAttribute('data-varientimg')){
              productImage.src = matchingVariant.getAttribute('data-varientimg');
            }
          }
        }
      });
    }
  }

  function thumbnailSlider(){
    $('.product-photo-thumbs').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      autoplay: false,
      autoplaySpeed: 1000,
      arrows: true,
    });
  }

