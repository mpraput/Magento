 document.addEventListener("DOMContentLoaded",function(){
     MobileMenu = function(){
        const hamburger = document.querySelector('.navbar-toggler');
        const navmobile = document.querySelector('.nav-mobile');
        const mobilenavclose = document.querySelector('.mobile-nav-close');
        hamburger.addEventListener('click', () => {
            navmobile.classList.toggle('active');
        });
        mobilenavclose.addEventListener('click', () => {
            navmobile.classList.remove('active');
        });

        var toggles = document.querySelectorAll('.submenu-m-toggle');
        toggles.forEach(function(toggle) {
            toggle.addEventListener('click', function() {
                var submenu = this.nextElementSibling; // Get the submenu related to the clicked toggle
                // Remove 'active' class from all submenu elements except the current one
                toggles.forEach(function(t) {
                    var otherSubmenu = t.nextElementSibling;
                    if (otherSubmenu !== submenu) {
                        otherSubmenu.classList.remove('active');
                    }
                });
                submenu.classList.toggle('active');
            });
        });

        // Optional: Close submenu when clicking outside
        document.addEventListener('click', function(event) {
            const isClickInsideNav = navmobile.contains(event.target) || hamburger.contains(event.target);
            if (!isClickInsideNav) {
                /* document.querySelectorAll('.submenu').forEach(submenu => {
                    submenu.classList.remove('active');
                });*/
                navmobile.classList.remove('active');
            }
        });
     }   

    MobileMenu();

    HomeBanner = function(){
        var banners         = document.querySelectorAll('.home-banner');
        if(banners.length > 0){
            var currentIndex    = 0;
            var slideInterval   = 5000; // 5 seconds
            function showSlide(index) {
                banners[currentIndex].classList.remove('active');
                currentIndex = (index + banners.length) % banners.length; // This ensures it loops properly
                banners[currentIndex].classList.add('active');
            }
            function showNextSlide() {
                showSlide(currentIndex + 1);
            }
            function showPrevSlide() {
                showSlide(currentIndex - 1);
            }

            // Initially show the first banner
            banners[currentIndex].classList.add('active');
            var autoSlide = setInterval(showNextSlide, slideInterval);
            document.querySelector('.next').addEventListener('click', function() {
                clearInterval(autoSlide); // Stop auto-sliding when manually changing
                showNextSlide();
                autoSlide = setInterval(showNextSlide, slideInterval); // Restart auto-sliding
            });
            document.querySelector('.prev').addEventListener('click', function() {
                clearInterval(autoSlide); // Stop auto-sliding when manually changing
                showPrevSlide();
                autoSlide = setInterval(showNextSlide, slideInterval); // Restart auto-sliding
            });
        }    
    }

    HomeBanner();

    
    //Start mini cart functionality
    _miniCart = function(){
        const cartIcon    = document.querySelector('#mini-cart-icon'); // Your cart icon
        const miniCart    = document.getElementById('mini-cart-popup');
        const closeButton = document.getElementById('close-mini-cart');
        // Toggle mini cart visibility
        cartIcon.addEventListener('click', function(e) {
            e.preventDefault()
            miniCart.style.display = miniCart.style.display === 'block' ? 'none' : 'block';
            document.querySelector('.mini-cart-content').classList.add('miniloader');
            updateMiniCart(); // Fetch cart data
        });
        // Close mini cart
        closeButton.addEventListener('click', function() {
            miniCart.style.display = 'none';
        });
    }
    _miniCart();
   
    async function updateMiniCart() {
        const cartItemsContainer = document.getElementById('cart-items'); // New container for items
        try {
            const response = await fetch('/cart.json');
            const data     = await response.json();
            cartItemsContainer.innerHTML = ''; // Clear existing items
            if (data.item_count > 0) {
                var cart_sub_total  = Shopify.formatMoney(data.items_subtotal_price);
                var cart_total      = Shopify.formatMoney(data.total_price);
                document.getElementById('minisubtotal').innerHTML =cart_sub_total;
                document.getElementById('minicarttotal').innerHTML =cart_total;
                let itemHTML        = '';
                data.items.forEach(item => {
                    const itemPrice = Shopify.formatMoney(item.price);
                    itemHTML += `
                        <div class="img-content"><div class="img"><img src="${item.image || 'https://via.placeholder.com/50'}" alt="${item.product_title}" style="width: 50px; height: auto;"></div>
                        <div class="content">
                            <p>${item.product_title}</p>
                            <p>Quantity: ${item.quantity}</p>
                            <p>Price: ${itemPrice}</p>
                            <button class="remove-item" data-id="${item.id}">Remove</button>
                        </div></div> `;            
                });
                cartItemsContainer.innerHTML += itemHTML; // Add item to cart
                document.querySelectorAll('.remove-item').forEach(button => {
                    button.addEventListener('click', function() {
                        document.querySelector('.mini-cart-content').classList.add('miniloader');
                        removeItemFromCart(this.dataset.id);
                    });
                });   
            } else {
                cartItemsContainer.innerHTML = '<p>Cart is empty! </p><a href="/collections/all/" class="btn btn-info">Continue Shopping</a>';
                document.getElementById('minisubtotal').innerHTML = '';
                document.getElementById('minicarttotal').innerHTML = '';
                document.querySelector('.subtotal').style.display = 'none';
                document.querySelector('.cart-total').style.display = 'none';
            }
            if(response.ok) {
                document.querySelector('.mini-cart-content').classList.remove('miniloader');
            }
        } catch (error) {
            console.error('Error fetching cart data:', error);
        }
    }

    async function removeItemFromCart(id) {
        try {
            const response = await fetch(`/cart/update.js`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    updates: {
                        [id]: 0 // Set quantity to 0 to remove
                    }
                })
            });
            if (response.ok) {
                updateMiniCart(); // Refresh mini cart after removing item
            } else {
                console.error('Failed to remove item from cart');
            }
        } catch (error) {
            console.error('Error removing item:', error);
        }
    }
    //End mini cart functionality
});