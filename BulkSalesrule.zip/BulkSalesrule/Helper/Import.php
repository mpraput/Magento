<?php
/**
 * Copyright © 6thstreet All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Import extends AbstractHelper
{

    /**
     * Media directory object (writable).
     *
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    private $mediaDirectory;

    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $file;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csv;

    protected $ruleFactory;
    protected $productRuleFactory;
    protected $foundProductRuleFactory;
    protected $ruleResource;


    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csv,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        \Magento\SalesRule\Model\Rule\Condition\ProductFactory $productRuleFactory,
        \Magento\SalesRule\Model\Rule\Condition\Product\FoundFactory $foundProductRuleFactory,
        \Magento\SalesRule\Model\ResourceModel\Rule $ruleResource
    ) {
        $this->mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->file = $file;
        $this->csv  = $csv;
        $this->ruleFactory = $ruleFactory;
        $this->productRuleFactory = $productRuleFactory;
        $this->foundProductRuleFactory = $foundProductRuleFactory;
        $this->ruleResource = $ruleResource;
        parent::__construct($context);
    }

    
    public function readDataFromCSVFile($filename='')
    {        
        $csvBasePath = "bulkrule/tmp/bulkrule";
        $path        = $this->mediaDirectory->getAbsolutePath($csvBasePath);
        $fullPath    = $path.'/'.$filename;

        if ($this->file->isExists($fullPath)) {
   
            $this->csv->setDelimiter(",");
            $data = $this->csv->getData($fullPath);
            $row  = 1;
            foreach ($data as $key => $value) {
                if($row == 1){
                    // heading                   
                }else{                    
                    $couponCode     = $value[0];
                    $userId         = $value[1];
                    $minCartValue   = $value[2];
                    $maxCouponDiscount      = $value[3];
                    $maxDiscountUpperLimit  = $value[4];
                    $numberOfUsages     = $value[5];
                    $startDate          = $value[6];
                    $endDate            = $value[7];
                    $rulename            = $value[8];
                    $ruleDescription            = $value[9];
                   
                    $this->createRule($couponCode, $minCartValue, $userId, $maxCouponDiscount, $maxDiscountUpperLimit, $numberOfUsages, $startDate, $endDate, $rulename, $ruleDescription);                  
                }
                $row++;
            }
        }

    }

    public function createRule($couponCode, $minCartValue, $userId, $maxCouponDiscount, $maxDiscountUpperLimit, $numberOfUsages, $startDate, $endDate, $rulename, $ruleDescription) {
        
        $result =  $this->generateCouponCode($couponCode, $minCartValue, $userId, $maxCouponDiscount, $maxDiscountUpperLimit, $numberOfUsages, $startDate, $endDate, $rulename, $ruleDescription);       
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $maxDiscountValue = ((float)$minCartValue*(float)$maxCouponDiscount)/100;
       
        if ($result !== false) {

            $connection = $objectManager->create('\Magento\Framework\App\ResourceConnection');
            $conn = $connection->getConnection();
            $table = $conn->getTableName('salesrule_coupon');        
            $query = "Select * FROM " . $table ." WHERE code = " ."'" .$result['coupon_code']."'" ;
            $resultCoupon = $conn->fetchAll($query);
         
            $salesRule = $this->ruleFactory->create();
            $ruleId    = $salesRule->getIdByCode($result['coupon_code']);
            
            if(isset($resultCoupon[0]['rule_id'])){
                $ruleId    = $resultCoupon[0]['rule_id']; 
                //from_date to_date expiration_dates
               // return;
            }

            // If the rule doesn't exist, create a new one // by_fixed
            if (!$ruleId) {
                $salesRule->setName($rulename);
                $salesRule->setDescription($ruleDescription);
                $salesRule->setCouponType(\Magento\SalesRule\Model\Rule::COUPON_TYPE_SPECIFIC);
                $salesRule->setCouponCode($result['coupon_code']);
            } else {

                $salesRule->load($ruleId);
            }
            // Set rule data
            $salesRule->setUseAutoGeneration(false);
            $salesRule->setStopRulesProcessing(false);
            $salesRule->setUsesPerCustomer($result['coupon_conditions']['number_of_usages']);
            $salesRule->setFromDate($result['coupon_conditions']['start_date']);
            $salesRule->setToDate($result['coupon_conditions']['end_date']);
            
            $salesRule->setUsesPerCoupon($numberOfUsages);
            $salesRule->setIsActive(true);
            $salesRule->setIsRss(true);
            $salesRule->setIsVisibleCart(false);
            $salesRule->setDiscountType('TIERED_PERCENT');
             $salesRule->setIsBulkCampaign('YES');
            $salesRule->setWebsiteIds([1,3,4]);
            $salesRule->setCustomerGroupIds(['1','4']);
            //$salesRule->setSimpleAction(\Magento\SalesRule\Model\Rule::BY_PERCENT_ACTION);
            $salesRule->setSimpleAction(\Magento\SalesRule\Model\Rule::BY_FIXED_ACTION);
            $salesRule->setDiscountAmount($maxDiscountValue);

             $dataS = json_encode([
                'type' => \Magento\SalesRule\Model\Rule\Condition\Combine::class,
                'attribute' => null,
                'operator' => null,
                'value' => '1',
                'is_value_processed' => null,
                'aggregator' => 'all',
                'conditions' => [
                    [
                        'type' => \Magento\SalesRule\Model\Rule\Condition\Address::class,
                        'attribute' => 'base_subtotal',
                        'operator' => '>=',
                        'value' => $minCartValue,
                        'is_value_processed' => false,
                    ],
                    [
                        'type' => \Amasty\Conditions\Model\Rule\Condition\CustomerAttributes::class,
                        'attribute' => 'email',
                        'operator' => '==',
                        'value' => $userId,
                        'is_value_processed' => false,
                    ],
                    /* [
                        'type' => \Apparel\TieredDiscount\Model\Rule\Condition\ApplicableDiscount::class,
                        'attribute' => 'applicable_discount',
                        'operator' => '==',
                        'value' => $maxDiscountUpperLimit,
                        'is_value_processed' => false,
                    ],*/
                     [
                        'type' => \Apparel\TieredDiscount\Model\Rule\Condition\ApplicableCapDiscount::class,
                        'attribute' => 'applicable_cap_discount',
                        'operator' => '==',
                        'value' => $maxDiscountUpperLimit,
                        'is_value_processed' => false,
                    ]]]);

            $salesRule->setConditionsSerialized($dataS);

            // Save the rule
            $salesRule->save();
        }
    }

    public function generateCouponCode($couponCode, $minCartValue, $userId, $maxCouponDiscount, $maxDiscountUpperLimit, $numberOfUsages, $startDate, $endDate) {

        // Validate parameters
        if (!$this->isValidEmail($userId) || !$this->isValidCartValue($minCartValue)) {
            return false; // Invalid parameters
        }

        // Generate coupon code
        //$length       = 4;
       // $characters   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
       // $randomString = substr(str_shuffle($characters), 0, $length);      
       // $couponCode   = $this->generateMonthYearCode() . $randomString . 'OFF';

        // Additional conditions for coupon
        $couponConditions = array(
            'min_cart_value'        => $minCartValue,
            'max_coupon_discount'   => $maxCouponDiscount,
            'max_discount_upper_limit_amount' => $maxDiscountUpperLimit,
            'number_of_usages'      => $numberOfUsages,
            'start_date'            => date("Y-m-d", strtotime($startDate)),
            'end_date'              => date("Y-m-d", strtotime($endDate)),
        );

        return array(
            'coupon_code' => $couponCode,
            'coupon_conditions' => $couponConditions,
        );
    }


    public function isValidEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }


    public function isValidCartValue($value)
    {
        return is_numeric($value) && $value > 0;
    }


    public function generateMonthYearCode()
    {
        return strtoupper(date('My'));
    }

}