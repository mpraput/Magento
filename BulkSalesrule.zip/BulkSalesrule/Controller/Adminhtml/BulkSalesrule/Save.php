<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Controller\Adminhtml\BulkSalesrule;

use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;
    protected $helperData;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Apparel\BulkSalesrule\Helper\Import $helperData
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->helperData = $helperData;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        $cartRuleCsv = $data['filename'];
        $data['filename'] = $cartRuleCsv[0]['name'];
        $data['created_at'] = date('d/m/Y');

      
        if ($data) {
            $id = $this->getRequest()->getParam('bulksalesrule_id');
        
            $model = $this->_objectManager->create(\Apparel\BulkSalesrule\Model\BulkSalesrule::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Bulksalesrule no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
        
            $model->setData($data);
            
            try {
                $model->save();

                $this->helperData->readDataFromCSVFile($data['filename']);

                $this->messageManager->addSuccessMessage(__('You saved the Bulksalesrule.'));
                $this->dataPersistor->clear('apparel_bulksalesrule_bulksalesrule');
        
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['bulksalesrule_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Bulksalesrule.'));
            }
        
            $this->dataPersistor->set('apparel_bulksalesrule_bulksalesrule', $data);
            return $resultRedirect->setPath('*/*/edit', ['bulksalesrule_id' => $this->getRequest()->getParam('bulksalesrule_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}

