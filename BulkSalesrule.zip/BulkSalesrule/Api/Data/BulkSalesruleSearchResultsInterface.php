<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Api\Data;

interface BulkSalesruleSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get BulkSalesrule list.
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface[]
     */
    public function getItems();

    /**
     * Set filename list.
     * @param \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

