<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Api\Data;

interface BulkSalesruleInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const FILENAME = 'filename';
    const BULKSALESRULE_ID = 'bulksalesrule_id';
    const CREATED_AT = 'created_at';

    /**
     * Get bulksalesrule_id
     * @return string|null
     */
    public function getBulksalesruleId();

    /**
     * Set bulksalesrule_id
     * @param string $bulksalesruleId
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setBulksalesruleId($bulksalesruleId);

    /**
     * Get filename
     * @return string|null
     */
    public function getFilename();

    /**
     * Set filename
     * @param string $filename
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setFilename($filename);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface $extensionAttributes
    );

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setCreatedAt($createdAt);
}

