<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface BulkSalesruleRepositoryInterface
{

    /**
     * Save BulkSalesrule
     * @param \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
    );

    /**
     * Retrieve BulkSalesrule
     * @param string $bulksalesruleId
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($bulksalesruleId);

    /**
     * Retrieve BulkSalesrule matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete BulkSalesrule
     * @param \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
    );

    /**
     * Delete BulkSalesrule by ID
     * @param string $bulksalesruleId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($bulksalesruleId);
}

