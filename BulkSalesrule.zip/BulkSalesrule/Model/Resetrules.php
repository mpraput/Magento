<?php
namespace Apparel\BulkSalesrule\Model;

use \Symfony\Component\Console\Command\Command;
use \Symfony\Component\Console\Input\InputInterface;
use \Symfony\Component\Console\Output\OutputInterface;

class Resetrules extends Command
{

	protected function configure()
	{
		$this->setName('bulksalesrule:coupondatereset')->setDescription('cart price rule date reset');

		parent::configure();
	}


	protected function execute(InputInterface $input, OutputInterface $output)
	{
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $connection    = $objectManager->create('\Magento\Framework\App\ResourceConnection');
        $conn = $connection->getConnection();

        $query = "SELECT sr.to_date , sr.is_bulk_campaign , src.rule_id , src.expiration_date FROM salesrule AS sr JOIN salesrule_coupon AS src ON sr.rule_id = src.rule_id WHERE DATE(src.created_at) > DATE('2023-12-06') AND DATE(sr.to_date) = CURDATE() AND sr.is_bulk_campaign = 'YES' LIMIT 100;" ;
        $result = $conn->fetchAll($query);

        foreach ($result as $key => $value) {
        	
        	$querySR = "UPDATE salesrule  SET to_date= DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE rule_id =  ".$value['rule_id'];
        	$conn->query($querySR);
        	$querySRC = "UPDATE salesrule_coupon SET expiration_date =  DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE rule_id = ".$value['rule_id'];
        	$conn->query($querySRC);
        }       

		$output->writeln('Bulksalesrule Coupondatereset Successfully');
	}
}




