<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Model;

use Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface;
use Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class BulkSalesrule extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'apparel_bulksalesrule_bulksalesrule';
    protected $dataObjectHelper;

    protected $bulksalesruleDataFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param BulkSalesruleInterfaceFactory $bulksalesruleDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule $resource
     * @param \Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        BulkSalesruleInterfaceFactory $bulksalesruleDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule $resource,
        \Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule\Collection $resourceCollection,
        array $data = []
    ) {
        $this->bulksalesruleDataFactory = $bulksalesruleDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve bulksalesrule model with bulksalesrule data
     * @return BulkSalesruleInterface
     */
    public function getDataModel()
    {
        $bulksalesruleData = $this->getData();
        
        $bulksalesruleDataObject = $this->bulksalesruleDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $bulksalesruleDataObject,
            $bulksalesruleData,
            BulkSalesruleInterface::class
        );
        
        return $bulksalesruleDataObject;
    }
}

