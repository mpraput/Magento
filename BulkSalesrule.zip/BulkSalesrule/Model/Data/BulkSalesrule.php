<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Model\Data;

use Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface;

class BulkSalesrule extends \Magento\Framework\Api\AbstractExtensibleObject implements BulkSalesruleInterface
{

    /**
     * Get bulksalesrule_id
     * @return string|null
     */
    public function getBulksalesruleId()
    {
        return $this->_get(self::BULKSALESRULE_ID);
    }

    /**
     * Set bulksalesrule_id
     * @param string $bulksalesruleId
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setBulksalesruleId($bulksalesruleId)
    {
        return $this->setData(self::BULKSALESRULE_ID, $bulksalesruleId);
    }

    /**
     * Get filename
     * @return string|null
     */
    public function getFilename()
    {
        return $this->_get(self::FILENAME);
    }

    /**
     * Set filename
     * @param string $filename
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setFilename($filename)
    {
        return $this->setData(self::FILENAME, $filename);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
}

