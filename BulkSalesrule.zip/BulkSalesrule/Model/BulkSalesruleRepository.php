<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Apparel\BulkSalesrule\Model;

use Apparel\BulkSalesrule\Api\BulkSalesruleRepositoryInterface;
use Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterfaceFactory;
use Apparel\BulkSalesrule\Api\Data\BulkSalesruleSearchResultsInterfaceFactory;
use Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule as ResourceBulkSalesrule;
use Apparel\BulkSalesrule\Model\ResourceModel\BulkSalesrule\CollectionFactory as BulkSalesruleCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class BulkSalesruleRepository implements BulkSalesruleRepositoryInterface
{

    private $collectionProcessor;

    protected $dataBulkSalesruleFactory;

    protected $dataObjectHelper;

    protected $resource;

    protected $searchResultsFactory;

    protected $dataObjectProcessor;

    protected $extensionAttributesJoinProcessor;

    protected $bulkSalesruleFactory;

    private $storeManager;

    protected $extensibleDataObjectConverter;
    protected $bulkSalesruleCollectionFactory;


    /**
     * @param ResourceBulkSalesrule $resource
     * @param BulkSalesruleFactory $bulkSalesruleFactory
     * @param BulkSalesruleInterfaceFactory $dataBulkSalesruleFactory
     * @param BulkSalesruleCollectionFactory $bulkSalesruleCollectionFactory
     * @param BulkSalesruleSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceBulkSalesrule $resource,
        BulkSalesruleFactory $bulkSalesruleFactory,
        BulkSalesruleInterfaceFactory $dataBulkSalesruleFactory,
        BulkSalesruleCollectionFactory $bulkSalesruleCollectionFactory,
        BulkSalesruleSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->bulkSalesruleFactory = $bulkSalesruleFactory;
        $this->bulkSalesruleCollectionFactory = $bulkSalesruleCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataBulkSalesruleFactory = $dataBulkSalesruleFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
    ) {
        /* if (empty($bulkSalesrule->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $bulkSalesrule->setStoreId($storeId);
        } */
        
        $bulkSalesruleData = $this->extensibleDataObjectConverter->toNestedArray(
            $bulkSalesrule,
            [],
            \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface::class
        );
        
        $bulkSalesruleModel = $this->bulkSalesruleFactory->create()->setData($bulkSalesruleData);
        
        try {
            $this->resource->save($bulkSalesruleModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the bulkSalesrule: %1',
                $exception->getMessage()
            ));
        }
        return $bulkSalesruleModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($bulkSalesruleId)
    {
        $bulkSalesrule = $this->bulkSalesruleFactory->create();
        $this->resource->load($bulkSalesrule, $bulkSalesruleId);
        if (!$bulkSalesrule->getId()) {
            throw new NoSuchEntityException(__('BulkSalesrule with id "%1" does not exist.', $bulkSalesruleId));
        }
        return $bulkSalesrule->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->bulkSalesruleCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Apparel\BulkSalesrule\Api\Data\BulkSalesruleInterface $bulkSalesrule
    ) {
        try {
            $bulkSalesruleModel = $this->bulkSalesruleFactory->create();
            $this->resource->load($bulkSalesruleModel, $bulkSalesrule->getBulksalesruleId());
            $this->resource->delete($bulkSalesruleModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the BulkSalesrule: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($bulkSalesruleId)
    {
        return $this->delete($this->get($bulkSalesruleId));
    }
}

