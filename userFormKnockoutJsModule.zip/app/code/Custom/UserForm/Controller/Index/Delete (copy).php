<?php

namespace Custom\UserForm\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Custom\UserForm\Model\UserFormFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
 
class Delete extends Action
{
    protected $resultPageFactory;
    protected $userFormFactory;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        UserFormFactory $userFormFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->userFormFactory = $userFormFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        try {
            $data = (array)$this->getRequest()->getPost();
            if ($data) {
                $model = $this->userFormFactory->create();
                
                // for the update data
                if(isset($data['id'])) {
                    $model->load($data['id']);
                }
            print_r($data);
            die();
                $model->setData($data)->save();
                $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __("We can\'t submit your request, Please try again."));
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
 
    }
}