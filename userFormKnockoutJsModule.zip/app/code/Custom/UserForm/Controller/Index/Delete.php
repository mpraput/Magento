<?php

namespace Custom\UserForm\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Custom\UserForm\Model\UserFormFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
 
class Delete extends Action
{

    protected $resultPageFactory;
    protected $userFormFactory;
    protected $jsonResultFactory;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        UserFormFactory $userFormFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->userFormFactory = $userFormFactory;
        $this->jsonResultFactory = $jsonResultFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        $resultJson = $this->jsonResultFactory->create();
        try {
            $data = (array)$this->getRequest()->getPost();           
            if ($data) {
                $model = $this->userFormFactory->create();               
                if(isset($data['id'])) {
                    $model->load($data['id']);                
                    $model->delete();
                    $this->messageManager->addSuccessMessage(__("Record Delete Successfully."));
                    $returndata['success']='success';
                }else{
                    $returndata['error']= 'no data';
                }   
            }else{
                $returndata['error']= 'no data';
            }
        } catch (\Exception $e) {
            $returndata['error']= 'error1';
            $this->messageManager->addErrorMessage($e, __("We can\'t delete record, Please try again."));
        }
        $result = $resultJson->setData($returndata);              
        return $result; 
    }
}