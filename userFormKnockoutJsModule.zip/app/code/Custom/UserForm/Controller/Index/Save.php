<?php

namespace Custom\UserForm\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Custom\UserForm\Model\UserFormFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
 
class Save extends Action
{

    protected $resultPageFactory;
    protected $userFormFactory;
    protected $jsonResultFactory;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        UserFormFactory $userFormFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->userFormFactory = $userFormFactory;
        $this->jsonResultFactory = $jsonResultFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        $resultJson = $this->jsonResultFactory->create();
        try {
            $pdata = (array)$this->getRequest()->getPost();
            if ($pdata) {
                $model = $this->userFormFactory->create();
                
                $data['fname'] = $pdata['fname'];
                $data['lname'] = $pdata['lname'];
                
                // for the update data
                if($pdata['userid']) {
                    $data['userform_id'] = $pdata['userid'];
                    $model->load($data['userform_id']);
                }            
                $model->setData($data)->save();
                $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
                $returndata['success']='success';
            }else{
                $returndata['nodata'] = 'no data';
            }
        } catch (\Exception $e) {
            $returndata['error']= $e->getMessage();
            //$this->messageManager->addErrorMessage($e, __("We can\'t submit your request, Please try again."));
        }
        
        $result = $resultJson->setData($returndata);              
        return $result;
    }
}