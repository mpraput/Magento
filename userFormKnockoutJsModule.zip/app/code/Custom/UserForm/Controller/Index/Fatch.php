<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Controller\Index;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

use Custom\UserForm\Model\ResourceModel\UserForm\CollectionFactory;

class Fatch extends Action
{


    /**
     * The JsonResultFactory to render with.
     *
     * @var jsonResultFactory
     */
    protected $jsonResultFactory;

    /**
     *
     * @var CollectionFactory
     */
    protected $_collectionFactory;

   
    public function __construct(
         Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        CollectionFactory $collectionFactory
    )
    {
        $this->jsonResultFactory = $jsonResultFactory;
        $this->_collectionFactory = $collectionFactory;
         parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        $resultJson = $this->jsonResultFactory->create();
        $data   = $this->_collectionFactory->create()->getData();
       
                //->addFieldToFilter('store_id', ['eq' => $storeId])  
        $result = $resultJson->setData($data);              
        return $result;
    }
}

