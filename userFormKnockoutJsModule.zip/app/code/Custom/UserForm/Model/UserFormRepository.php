<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Model;

use Custom\UserForm\Api\Data\UserFormInterface;
use Custom\UserForm\Api\Data\UserFormInterfaceFactory;
use Custom\UserForm\Api\Data\UserFormSearchResultsInterfaceFactory;
use Custom\UserForm\Api\UserFormRepositoryInterface;
use Custom\UserForm\Model\ResourceModel\UserForm as ResourceUserForm;
use Custom\UserForm\Model\ResourceModel\UserForm\CollectionFactory as UserFormCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class UserFormRepository implements UserFormRepositoryInterface
{

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var UserForm
     */
    protected $searchResultsFactory;

    /**
     * @var ResourceUserForm
     */
    protected $resource;

    /**
     * @var UserFormInterfaceFactory
     */
    protected $userFormFactory;

    /**
     * @var UserFormCollectionFactory
     */
    protected $userFormCollectionFactory;


    /**
     * @param ResourceUserForm $resource
     * @param UserFormInterfaceFactory $userFormFactory
     * @param UserFormCollectionFactory $userFormCollectionFactory
     * @param UserFormSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceUserForm $resource,
        UserFormInterfaceFactory $userFormFactory,
        UserFormCollectionFactory $userFormCollectionFactory,
        UserFormSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->userFormFactory = $userFormFactory;
        $this->userFormCollectionFactory = $userFormCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(UserFormInterface $userForm)
    {
        try {
            $this->resource->save($userForm);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the userForm: %1',
                $exception->getMessage()
            ));
        }
        return $userForm;
    }

    /**
     * @inheritDoc
     */
    public function get($userFormId)
    {
        $userForm = $this->userFormFactory->create();
        $this->resource->load($userForm, $userFormId);
        if (!$userForm->getId()) {
            throw new NoSuchEntityException(__('UserForm with id "%1" does not exist.', $userFormId));
        }
        return $userForm;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->userFormCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(UserFormInterface $userForm)
    {
        try {
            $userFormModel = $this->userFormFactory->create();
            $this->resource->load($userFormModel, $userForm->getUserformId());
            $this->resource->delete($userFormModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the UserForm: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($userFormId)
    {
        return $this->delete($this->get($userFormId));
    }
}

