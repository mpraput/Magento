<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Model\ResourceModel\UserForm;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'userform_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Custom\UserForm\Model\UserForm::class,
            \Custom\UserForm\Model\ResourceModel\UserForm::class
        );
    }
}

