<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Model;

use Custom\UserForm\Api\Data\UserFormInterface;
use Magento\Framework\Model\AbstractModel;

class UserForm extends AbstractModel implements UserFormInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Custom\UserForm\Model\ResourceModel\UserForm::class);
    }

    /**
     * @inheritDoc
     */
    public function getUserformId()
    {
        return $this->getData(self::USERFORM_ID);
    }

    /**
     * @inheritDoc
     */
    public function setUserformId($userformId)
    {
        return $this->setData(self::USERFORM_ID, $userformId);
    }

    /**
     * @inheritDoc
     */
    public function getFname()
    {
        return $this->getData(self::FNAME);
    }

    /**
     * @inheritDoc
     */
    public function setFname($fname)
    {
        return $this->setData(self::FNAME, $fname);
    }

    /**
     * @inheritDoc
     */
    public function getLname()
    {
        return $this->getData(self::LNAME);
    }

    /**
     * @inheritDoc
     */
    public function setLname($lname)
    {
        return $this->setData(self::LNAME, $lname);
    }
}

