define([
'jquery',	
'uiComponent',
'ko',
'mage/url',
'mage/validation'
], function($, Component, ko, urlBuilder) {
    selectorForm = null;
	var self = null;
	return Component.extend({
	    
	    clock: ko.observable(""),
	    someText: ko.observable(""),

	    fname: ko.observable(""),
	    lname: ko.observable(""),
	    userid: ko.observable(""),

	    allRecords: ko.observableArray([]),
	    isLoader: ko.observable(false),
	    
	    initialize: function (config) {
	    	self = this;
	    	const { is_show } = config;
	        this._super();
	        setInterval(this.reloadTime.bind(this),1000);
	        this.someText(is_show); 
	        self.getRcords();	       
	    },
	    reloadTime: function () {
	         /* Setting new time to our clock variable. DOM manipulation will happen automatically */
	         this.clock(Date());
	    },
	    getClock: function () {
	         return this.clock;
	    },
	    getSomeText: function(){
	    	
	    	return this.someText;
	    },
	    getRcords: function () {
            self.isLoader(true);
            var dataid = 2; 	
            const url = urlBuilder.build('myfrom/index/fatch')
            $.ajax({
                url: url,
                type: 'POST',
                dataType: 'json',
                data: dataid,
                showLoader: true,
                success: function(result,status,xhr){
                	console.log(result);
                    self.allRecords(result);
                },
                complete: function(response) {      
                    console.log('complete.');
                },
                error: function (xhr, status, errorThrown) {                   
                    console.log('Error happens. Try again.');
                }
            });
        },

        onSubmitUserForm: function (target) {
            const dataIsValid = selectorForm.validation('isValid');                     
            if(dataIsValid){
            	const formData = $('.form.form-login').serializeArray();
            	const posturl = urlBuilder.build('myfrom/index/save')
            	console.log(formData);            	
            	$.ajax({
	                url: posturl,
	                type: 'POST',
	                dataType: 'json',
	                data: formData,
	                showLoader: true,
	                success: function(result,status,xhr){
	                	console.log(result);
	                	$('.form.form-login')[0].reset();
	                    self.getRcords();
	                    self.userid('');
	                },
	                complete: function(response) {      
	                    console.log('complete.');
	                },
	                error: function (xhr, status, errorThrown) {                   
	                    console.log('Error happens. Try again.');
	                }
	            });
            }            
        },
        /**
         * 
         * It id for the form validations 
         */
        setFormValidationRule : function (target) {
            if (target) {
                selectorForm = $(target);
                var ignore = null;
                selectorForm.mage('validation', {
                    ignore: ignore ? ':hidden:not(' + ignore + ')' : ':hidden'
                }).find('input:text').attr('autocomplete', 'off');
            }
        },

        callFunctionToEdit : function(target){
        	console.log(target);
        	self.fname(target.fname);
        	self.lname(target.lname);
        	self.userid(target.userform_id);
        },

        callFunctionToDelete : function(target){
        	if (confirm('Do you want to proceed?')) {
	        	console.log(target.userform_id);
	        	if(target.userform_id){
	        		var userid 		= target.userform_id;
	        		const posturl 	= urlBuilder.build('myfrom/index/delete');            	
	            	$.ajax({
		                url: posturl,
		                type: 'POST',
		                dataType: 'json',
		                data: {id: userid},
		                showLoader: true,
		                success: function(result,status,xhr){
		                	console.log(result.success);
		                	if( result.success =='success'){
		                		self.getRcords();  // relaod list data
		                	}	                    
		                },
		                complete: function(response) {      
		                    //console.log('complete.');
		                },
		                error: function (xhr, status, errorThrown) {                   
		                    console.log('Error happens. Try again.');
		                }
		            });
	        	}
        	}
        },      
	});
});