<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface UserFormRepositoryInterface
{

    /**
     * Save UserForm
     * @param \Custom\UserForm\Api\Data\UserFormInterface $userForm
     * @return \Custom\UserForm\Api\Data\UserFormInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Custom\UserForm\Api\Data\UserFormInterface $userForm
    );

    /**
     * Retrieve UserForm
     * @param string $userformId
     * @return \Custom\UserForm\Api\Data\UserFormInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($userformId);

    /**
     * Retrieve UserForm matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Custom\UserForm\Api\Data\UserFormSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete UserForm
     * @param \Custom\UserForm\Api\Data\UserFormInterface $userForm
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Custom\UserForm\Api\Data\UserFormInterface $userForm
    );

    /**
     * Delete UserForm by ID
     * @param string $userformId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($userformId);
}

