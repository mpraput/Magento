<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Api\Data;

interface UserFormSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get UserForm list.
     * @return \Custom\UserForm\Api\Data\UserFormInterface[]
     */
    public function getItems();

    /**
     * Set fname list.
     * @param \Custom\UserForm\Api\Data\UserFormInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

