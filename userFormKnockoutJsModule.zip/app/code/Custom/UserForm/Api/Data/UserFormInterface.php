<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\UserForm\Api\Data;

interface UserFormInterface
{

    const USERFORM_ID = 'userform_id';
    const FNAME = 'fname';
    const LNAME = 'lname';

    /**
     * Get userform_id
     * @return string|null
     */
    public function getUserformId();

    /**
     * Set userform_id
     * @param string $userformId
     * @return \Custom\UserForm\UserForm\Api\Data\UserFormInterface
     */
    public function setUserformId($userformId);

    /**
     * Get fname
     * @return string|null
     */
    public function getFname();

    /**
     * Set fname
     * @param string $fname
     * @return \Custom\UserForm\UserForm\Api\Data\UserFormInterface
     */
    public function setFname($fname);

    /**
     * Get lname
     * @return string|null
     */
    public function getLname();

    /**
     * Set lname
     * @param string $lname
     * @return \Custom\UserForm\UserForm\Api\Data\UserFormInterface
     */
    public function setLname($lname);
}

