<?php
namespace Custom\CategoryAttribute\Plugin;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Catalog\Api\Data\ProductExtensionFactory;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;

class ProductRepositoryPlugin
{
    protected $stockRegistry;
    protected $productExtensionFactory;

    public function __construct(
        StockRegistryInterface $stockRegistry,
        ProductExtensionFactory $productExtensionFactory,
        ProductAttributeRepositoryInterface $attributeRepository
    ) {
        $this->stockRegistry = $stockRegistry;
        $this->productExtensionFactory = $productExtensionFactory;
        $this->attributeRepository = $attributeRepository;
    }

    public function afterGetList(
        ProductRepositoryInterface $subject,
        \Magento\Catalog\Api\Data\ProductSearchResultsInterface $searchCriteria
    ) {
        $products = $searchCriteria->getItems();

        $dropDownAttributes = ['origin','stone_color','stone_shape','treatment_new','certificate_type','cut'];

        foreach ($products as $product) {
            $productId = $product->getId();
            $stockItem = $this->stockRegistry->getStockItem($productId);
            
            $stockId = $stockItem->getStockId(); // Get quantity
            $stockQty = $stockItem->getQty(); // Get quantity
            $isInStock = $stockItem->getIsInStock(); // Check if in stock
            $item_id  = $stockItem->getItemId(); // Check if in stock

            // Add stock information to product extension attributes
            $productExtension = $product->getExtensionAttributes();
            if ($productExtension === null) {
                $productExtension = $this->productExtensionFactory->create();
            }
            $productExtension->setStockId($stockId);
            $productExtension->setItemId($item_id);
            $productExtension->setStockQty($stockQty);
            $productExtension->setIsInStock($isInStock);
            $product->setExtensionAttributes($productExtension);

            $customAttributes = $product->getCustomAttributes();
            foreach ($customAttributes as $attribute) {
                if(in_array($attribute->getAttributeCode(), $dropDownAttributes)){
                    $attribute->setValue($this->getLabelForValue($attribute->getAttributeCode(), $attribute->getValue()));
                }
            }
        }
        
        return $searchCriteria;
    }

    
    protected function getLabelForValue($attributeCode, $value)
    {
        try {
            $attribute = $this->attributeRepository->get($attributeCode);
            foreach ($attribute->getOptions() as $option) {
                if ($option->getValue() == $value) {
                    return $option->getLabel();
                }
            }
        } catch (\Exception $e) {
            return $value; // Return the value itself if label not found
        }
        return $value; // Return the value itself if label not found
    }

/*<pre>Array
(
    [item_id] => 966
    [product_id] => 1303
    [stock_id] => 1
    [qty] => 0.0000
    [min_qty] => 0.0000
    [use_config_min_qty] => 1
    [is_qty_decimal] => 0
    [backorders] => 0
    [use_config_backorders] => 1
    [min_sale_qty] => 1.0000
    [use_config_min_sale_qty] => 1
    [max_sale_qty] => 0.0000
    [use_config_max_sale_qty] => 1
    [is_in_stock] => 0
    [low_stock_date] => 2015-05-24 16:32:46
    [notify_stock_qty] => 
    [use_config_notify_stock_qty] => 1
    [manage_stock] => 0
    [use_config_manage_stock] => 1
    [stock_status_changed_auto] => 1
    [use_config_qty_increments] => 1
    [qty_increments] => 0.0000
    [use_config_enable_qty_inc] => 1
    [enable_qty_increments] => 0
    [is_decimal_divided] => 0
    [website_id] => 2
    [type_id] => simple
)
</pre>*/

}
