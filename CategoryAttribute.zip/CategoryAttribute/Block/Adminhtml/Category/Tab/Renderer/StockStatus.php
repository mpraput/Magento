<?php
namespace Custom\CategoryAttribute\Block\Adminhtml\Category\Tab\Renderer;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\DataObject;

class StockStatus extends AbstractRenderer
{
    public function render(DataObject $row)
    {
        $qty = $row->getData('qty');
        if($qty > 0){
            return '<span style="color: green;">In Stock</span>';
        }else{
            return '<span  style="color: red;">No Stock</span>';
        }
    }
}
