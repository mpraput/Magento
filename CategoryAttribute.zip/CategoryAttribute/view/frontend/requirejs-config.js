var config = {
    config: {
        mixins: {
            'Magento_ReCaptchaFrontendUi/js/reCaptcha': {
                'Custom_CategoryAttribute/js/reCaptcha-mixin': true
            }
        }
    }
};